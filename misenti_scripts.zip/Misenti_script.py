# Final Project: Midwest or Bust
# 

# Created by: Joi Misenti
#
# Created on: 2016-04-10
# Updated on: 2016-05-13

'''
This script aims to compile several spatial parameters in the South Bend,
Indiana area surrounding the campus of Notre Dame University. Each
additional factor will impose limits on the areas desired for habitation.
Ultimately, the factors will be overlayed to generate a rudimentary site
suitability analysis for a potential move.

'''

# 1. import arcpy, sys, and traceback modules

import arcpy, sys, traceback, os, datetime

author = 'J. Misenti'  # Change this to your name

print "The author of this code is " + author
print "This script will perform a site suitability analysis of South Bend, IN"

# reformat date to MM.DD.YYYY
# NOTE: lowercase %y will result in MM.DD.YY format
# See Python.org or text regarding the datetime module

CUR_DATE = datetime.date.today().strftime('%m.%d.%Y')

print "Today's date is: " + CUR_DATE

# 2. Create workspace

aFolder = r"C:\Users\Jar\Documents\ARC Schoolwork\GEOG 375 Intro GIS Programming\Final Project"
fileGD = os.path.join(aFolder, "South_Bend_proj.gdb")
arcpy.env.workspace = fileGD


# 3. Create variable definitions for geoprocessing functions

# South Bend Neighborhoods

neighborhoods_in = os.path.join(aFolder, "ZillowNeighborhoods.shp")
neighborhoods_clip = 'Study_Area'
neighborhoods_out = os.path.join(fileGD, "South_Bend_hoods")
neighborhoods_project = 'South_Bend_neighborhoods'
neighborhoods_project_layer = 'South_Bend_neighborhoods_layer'
SB_neighborhood_rent = os.path.join(aFolder, "SB_AllHomes_byNeigh_ADJUSTED.csv")

# South Bend block groups

us_blockgroups = 'ACS0913_bg_Clip'
bgs_clip = 'Study_Area'
SB_bgs = 'South_Bend_blockgroups'
SB_bgs_layer = 'South_Bend_blockgroups_layer'

# South Bend (in St. Joseph County) zip codes

county_zip = 'stjoseph_county_zip'
county_zip_layer = 'stjoseph_county_zip_layer'
SB_zip = 'South_Bend_zip'
SB_zip_layer = 'South_Bend_zip_layer'
SB_zip_rent = os.path.join(aFolder, "SB_AllHomes_byZipADJUSTED.csv")

# Union

SB_union = 'South_Bend_Area_Union'
SB_union_layer = 'South_Bend_Area_Union_Layer'

# Notre Dame

ND = 'Notre_Dame'
ND_buffer = 'Notre_Dame_Buffer'
cities = 'city_names'
cities_layer = 'city_names_layer'

# 4. Add try: and except: blocks

try:

    # Clip the Indiana neighborhoods shapefile obtained from Zillow.com that
    # contains some neighborhoods from South Bend and some from Fort Wayne.
    # Since the focus here is South Bend, use Clip routine.
    # Add Clip routine

    if arcpy.Exists(neighborhoods_out):
        arcpy.Delete_management(neighborhoods_out)

    print "Starting Clip routine for South Bend neighborhoods"

    arcpy.Clip_analysis(neighborhoods_in, neighborhoods_clip, neighborhoods_out)

    print "Finished Clip routine for South Bend neighborhoods"

    # Clip the block groups feature class obtained from the American Community
    # Survey(ACS) data so that we only have those block groups relevant to
    # South Bend, and not the entire United States. This will greatly improve
    # processing speed for further operations. Note: for general housekeeping,
    # the ACS feature class has already been trimmed of some 300+ attribute 
    # fields irrelevant for purposes here.
    # Add Clip routine

    if arcpy.Exists(SB_bgs):
        arcpy.Delete_management(SB_bgs)

    print "Starting Clip routine for South Bend block groups"

    arcpy.Clip_analysis(us_blockgroups, bgs_clip, SB_bgs)

    print "Finished Clip routine for South Bend block groups"

    # The South Bend neighborhoods feature class is based on NAD83 while
    # the rest of the data to be used is in WGS84. Use Project and
    # transform neighborhoods to match other feature class coordinate systems.

    print "Starting Project routine for South Bend neighborhoods"

    if arcpy.Exists(neighborhoods_project):
        arcpy.Delete_management(neighborhoods_project)

    # Project routine:
    # Input feature class: previously clipped neighborhoods file.
    # Output feature class: new neighborhoods file.
    # Reference coordinate system: from previously clipped
    # South Bend block groups feature class, which has the correct
    # coordinate system along with a modified central meridian that highlights
    # the center of the study area.

    arcpy.Project_management(neighborhoods_out, neighborhoods_project, SB_bgs, \
                             "NAD_1983_To_WGS_1984_5", "", "PRESERVE_SHAPE")

    print "Finished projecting South Bend neighborhoods"

    # Create South Bend city zip codes feature class by extracting them from St.Joseph
    # County zip codes feature class. Make a feature layer from the county
    # zip codes in order to then select the specific South Bend zips followed by
    # Copy Features routine to export the current selection.

    if arcpy.Exists(county_zip_layer):
        arcpy.Delete_management(county_zip_layer)

    # Make Feature Layer for county zip codes
    arcpy.MakeFeatureLayer_management(county_zip, county_zip_layer)

    print "Finished making Feature Layer for St.Joseph County zip codes"

    # Select Layer By Attribute to specify zip codes in city of South Bend
    query = """"PO_NAME" = 'Granger' OR "PO_NAME" = 'Mishawaka' OR "PO_NAME" = 'Notre Dame' OR "PO_NAME" = 'Osceola' OR "PO_NAME" = 'South Bend'"""
    arcpy.SelectLayerByAttribute_management(county_zip_layer, "NEW_SELECTION", query)

    print "Much surprise that absurdly long compound query has correct syntax!"

    # Before exporting, check if South Bend zips feature class exists

    if arcpy.Exists(SB_zip):
        arcpy.Delete_management(SB_zip)

    # Copy Features
    # Copy the selected zip code polygon features to a new feature class
    arcpy.CopyFeatures_management(county_zip_layer, SB_zip, "", "0", "0", "0")

    print "Copied selected features from " + county_zip + " to " + SB_zip

    # Here emerged an unexpected problem. The 'Zip' code attribute field for SB_zips was
    # in a String data format, but I will need to add a Join to another table (based on
    # zip codes) whose zips are in a number format.
    # To resolve this, I consulted extensive ArcGIS Desktop Help pages and Python forums;
    # many original conversion options are defunct with current versions of ArcGIS.
    # Finally, an interesting solution came from a forum poster's script to parse
    # Field Calculator with a brief function to convert string to integer.
    # Code Reference: posted by user 'erath' on
    # web forum--https://geonet.esri.com/thread/86096

    # Add a new zip code field of an integer type data format to hold the original zip
    # field's string values
    
    arcpy.AddField_management(SB_zip, "ZIP_INT", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

    print 'Calculating stupid zip'

    # Process: Calculate Field (3)
    arcpy.CalculateField_management(SB_zip, "ZIP_INT", "get_num_from_string(!ZIP!)", "PYTHON_9.3", \
                                    ("def get_num_from_string(string):  \\n    '''This function retrieves numbers and converts them to integers'''  \\n\
    num = ''  \\n    # Create empty string to store numbers as string  \\n\
    for i in string:  \\n    # Loop through characters in the string  \\n\
        if i in '1234567890':  \\n    # If one of the characters is a number, add it to the empty string  \\n\
                num += i  \\n\
    integer = int(num)  \\n    return integer"))        # Convert the string of numbers to an integer

    print 'Finished calculating stupid zip'
    # This whole process of finding a method was an interesting adventure into
    # nuances of Python way beyond my depth



    # Analysis

    # Now that inputs are prepped, can begin actual analysis of South Bend
    # area and parameters.

    # PARAMETER A: Education
    # First parameter to analyze is quotient of people in each block group
    # who possess a Bachelor's degree or higher.

    # Add field to hold quotient of populace surveyed with Bachelor's degree

    print "Adding field 'Bachelors' to block groups attribute table"

    arcpy.AddField_management(SB_bgs, "BACHELORS", "FLOAT")

    print "Finished adding field 'Bachelors'"

    # Populate BACHELORS field with Field Calculator expression
    # Expression used divided the total number of people 25 and above who
    # hold Bachelor's degrees (or higher) by the total number of respondents
    # 25 years and above surveyed for education/degree

    # Calculate Field

    arcpy.CalculateField_management(SB_bgs, "BACHELORS", "[ACSBACHDEG] / [ACSEDUCBAS]", "VB", "")

    print "Finished calculating and filling 'Bachelors' field"
        
    # Now that first analysis results are in, can begin a ranking system
    # for site preference. This ranking will be stored in a new field
    # called 'Priority'.

    # Add Field called 'Priority'
    arcpy.AddField_management(SB_bgs, "PRIORITY", "SHORT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

    print "Finished adding field 'Priority'"

    # Make Feature Layer in order to select South Bend block groups
    # that meet Bachelor's threshold

    if arcpy.Exists(SB_bgs_layer):
        arcpy.Delete_management(SB_bgs_layer)
        
    arcpy.MakeFeatureLayer_management(SB_bgs, SB_bgs_layer)

    # Process: Select Layer By Attribute with a query
    # that limits selection to only those block groups with
    # 25% or more of occupants holding Bachelor's degrees

    bach_query = """"BACHELORS" >= 0.25"""
    
    arcpy.SelectLayerByAttribute_management(SB_bgs_layer, "NEW_SELECTION", bach_query)

    num_features = arcpy.GetCount_management(SB_bgs_layer)

    # Do a self-check with the GetCount routine that sums
    # the number of selected block groups meeting the query.

    print "Number of selected block groups with 25% or above possessing Bachelors degree: " + \
          str(num_features)

    # Education clears the first preference, allowing those
    # block groups meeting the minimum quotient threshold
    # to be assigned a rank of '3'.
    
    # Process: Calculate Field to populate selected records with rank '3'.
    arcpy.CalculateField_management(SB_bgs_layer, "PRIORITY", "3", "VB", "")

    print "Populated " + str(num_features) + " records with Priority 3"

    # PARAMETER B: Rent Cost
    # Second parameter is to analyze recent average rent costs in the South Bend area.
    # Rent statistics were obtained from Zillow as a time series dating back
    # to the year 2010. After unsuccessfully trying code to modify the numeric
    # Year/Date field names, ended up manually changing to proper characters
    # to allow for smooth import to ArcGIS.

    # Rent stored in a Zillow .csv file so in order to analyze, must Join
    # to feature classes/feature layers.

    # a) Join the zip codes feature class to zip code .csv rent statistics

    # We will create indexes for the zip codes feature class, but
    # first we check to see if they exist

    # list the indexes for the SB_zip feature class

    indexes = arcpy.ListIndexes(SB_zip)
    for index in indexes:
        # if the index name already exists in the list of indexes, remove it
        if (index.name == 'Zip_Index'):
            arcpy.RemoveIndex_management(SB_zip, 'Zip_Index')

    # Process: Create indexes for the feature class

    arcpy.AddIndex_management(SB_zip, 'ZIP_INT', 'Zip_Index', 'UNIQUE', 'NON_ASCENDING')

    # Check if feature layer for zip codes exists

    if arcpy.Exists(SB_zip_layer):
        arcpy.Delete_management(SB_zip_layer)
        
    # Process: Make Feature Layer to facilitate Join
    arcpy.MakeFeatureLayer_management(SB_zip, SB_zip_layer)

    # Process: Add Join
    arcpy.AddJoin_management(SB_zip_layer, "ZIP_INT", \
                             SB_zip_rent, "RegionName", "KEEP_ALL")

    print "Successfully joined the zip codes feature class to the rent .csv file"

    # print list of fields for troubleshooting

    fields = arcpy.ListFields(SB_zip_layer)
    for field in fields:
        print field.name
    del field, fields

    # b) Join the neighborhoods fc to neighborhood .csv rent statistics

    # We will create indexes for the neighborhoods feature class, but
    # first we check to see if they exist

    # list the indexes for the SB_neighborhood feature class

    indexes = arcpy.ListIndexes(neighborhoods_project)
    for index in indexes:
        # if the index name already exists in the list of indexes, remove it
        if (index.name == 'Region_Index'):
            arcpy.RemoveIndex_management(neighborhoods_project, 'Region_Index')

    # Process: Create indexes for the feature class

    arcpy.AddIndex_management(neighborhoods_project, 'REGIONID', 'Region_Index', \
                              'UNIQUE', 'NON_ASCENDING')

    # Check if feature layer for neighborhoods exists

    if arcpy.Exists(neighborhoods_project_layer):
        arcpy.Delete_management(neighborhoods_project_layer)
        
    # Process: Make Feature Layer to facilitate Join
    arcpy.MakeFeatureLayer_management(neighborhoods_project, neighborhoods_project_layer)

    # Process: Add Join
    arcpy.AddJoin_management(neighborhoods_project_layer, "REGIONID", \
                             SB_neighborhood_rent, "RegionID", "KEEP_ALL")

    print "Successfully joined neighborhoods with rent .csv file"

    # print list of fields for troubleshooting

    fields = arcpy.ListFields(neighborhoods_project_layer)
    for field in fields:
        print field.name
    del field, fields

    # The neighborhoods feature class is not complete; only some areas of South
    # Bend are included as polygons in the neighborhoods feature class.
    # So an analysis of purely neighborhood rent prices would be incomplete.
    # Hence, combine the block groups, zip codes, and neighborhood
    # feature classes to compensate for gaps in the data and
    # corresponding rent data. Fill in neighborhood holes with data from
    # block groups and zip codes, which are the next best resolution.

    # Process: Union

    # Create variable to hold the feature layers for input to Union routine
    # as well as output variable
    in_Union = [[SB_zip_layer, 2], [neighborhoods_project_layer, 1], [SB_bgs_layer, 2]]
    out_Union = SB_union

    if arcpy.Exists(out_Union):
        arcpy.Delete_management(out_Union)

    # Perform Union
    
    arcpy.Union_analysis(in_Union, out_Union, "ALL", "", "GAPS")

    print "Successful Union from Neighborhoods, Zip Codes, and Block Groups"

    # Now that feature and polygon data have been stitched together,
    # we fill in gaps in the data. Namely, fill in holes in rent data.
    
    # Process: Make Feature Layer
    # check if feature layer exists
    if arcpy.Exists(SB_union_layer):
        arcpy.Delete_management(SB_union_layer)
        
    arcpy.MakeFeatureLayer_management(SB_union, SB_union_layer)

    print "Finished making feature layer of South Bend Union feature class"

    # Process: Select Layer By Attribute
    # Selects records where the most recent rent data (field: March 2016) is 0
    # or Null

    union_query = """"SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03" IS NULL OR "SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03" = 0"""
    arcpy.SelectLayerByAttribute_management(SB_union_layer, "NEW_SELECTION", \
                                            union_query)

    # Do a self-check with the GetCount routine that sums
    # the number of selected polygons meeting the query.

    num_features = arcpy.GetCount_management(SB_union_layer)

    print "Number of selected polygons without a rent price statistic: " + \
          str(num_features)

    # Process: Calculate Field
    # Fill in data gaps by transferring the larger zip code rent data into
    # empty subset block group/neighborhood data
    arcpy.CalculateField_management(SB_union_layer, \
                                    "SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03", \
                                    "[SB_AllHomes_byZipADJUSTED_csv_Y2016_M03]", "VB", "")

    print "Populated " + str(num_features) + " records with a rent statistic"

    # In the Union, some records were generated with almost all NULL values and '0's
    # for sliver polygons . Use an Update Cursor to select and
    # delete them

    # set a variable for the most recent rent field:
    # "SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03"

    recent_rent_field = "SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03"

    # set a variable to hold the query string

    with arcpy.da.UpdateCursor(SB_union, recent_rent_field) as deletes:
        for row in deletes:
            if row[0] == 0:
                deletes.deleteRow()

        del deletes, row

    print "Successfully deleted empty rows"
 
    num_features = arcpy.GetCount_management(SB_union)

    print "Number of records remaining is: " + str(num_features)

    # Now we've obtained rent price statistics for majority of polygon features

    # Update Priority field that satisfies both the degree-holding
    # and rent requirements with '2'

    # construct query to specify records
    query = """"BACHELORS" >= 0.25 AND "SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03" <= 850"""

    with arcpy.da.UpdateCursor(SB_union, "PRIORITY", query) as urows:
        for row in urows:
            row[0] = 2
            urows.updateRow(row)

    print "Successfully updated rows satisfying both parameters with Priority '2'"
    
    # PARAMETER C: Distance to Notre Dame University
    # As for last parameter, ideally we would want to be closer to the university
    # for convenience and gas mileage. Considering car availability, is not
    # a huge limiting factor so saved this parameter for last, as a
    # more superfluous construct.

    # Make a new feature class of Notre Dame alone to perform Buffer distance analysis

    # Process: Make Feature Layer to select Notre Dame from a broader cities layer
    print "Making feature layer for cities"
    if arcpy.Exists(cities_layer):
        arcpy.Delete(cities_layer)
    arcpy.MakeFeatureLayer_management(cities, cities_layer)
    print "Finished making feature layer for cities"

    # Process: Select Layer By Attribute
    arcpy.SelectLayerByAttribute_management(cities_layer, "NEW_SELECTION", "NAME = 'Notre Dame'")

    print "Starting to extract Notre Dame from cities"
    # Process: Copy Features
    if arcpy.Exists(ND):
        arcpy.Delete_management(ND)
    arcpy.CopyFeatures_management(cities_layer, ND, "", "0", "0", "0")
    print "Finished Notre Dame feature class"

    print "Drawing buffer around Notre Dame"
    # Process: Buffer
    # Create a buffer zone around the university so that only priority 2 features that fall
    # within the radius will be upgraded to priority 1
    if arcpy.Exists(ND_buffer):
        arcpy.Delete_management(ND_buffer)
    arcpy.Buffer_analysis(ND, ND_buffer, "1.5 Miles", "FULL", "ROUND", "NONE", "", "PLANAR")

    print "Buffer drawn"

    # Process: Select Layer By Location
    # Select all features in union layer that intersect the buffer zone
    arcpy.SelectLayerByLocation_management(SB_union_layer, "INTERSECT", \
                                           ND_buffer, "", "NEW_SELECTION", \
                                           "NOT_INVERT")

    # Process: Select Layer By Attribute
    # From current selection, refine selected features that also satisfy
    # the prerequisites identified earlier
    arcpy.SelectLayerByAttribute_management(SB_union_layer, "SUBSET_SELECTION", \
                                            "SB_AllHomes_byNeigh_ADJUSTED_csv_Y2016_M03 <= 850 AND BACHELORS >= 0.25")

    # Do a self-check with the GetCount routine that sums
    # the number of selected polygons meeting the query.
    num_features = arcpy.GetCount_management(SB_union_layer)

    print "Number of selected polygons satisfying all parameters: " + \
          str(num_features)

    # All features in the union polygon that satisfy the 3 requirements--
    # education, rental listing price, and distance to school--have been
    # identified. These features will be assigned priority of '1'.
    
    # Process: Calculate Field to populate selected records with rank '1'.
    arcpy.CalculateField_management(SB_union_layer, "PRIORITY", "1", "VB", "")

    print "Populated " + str(num_features) + " records with Priority '1'"

    print "And to all a good night."
    

except:


    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback Info:\n" + tbinfo + "\nError Info:\n     " +        str(sys.exc_type) + ": " + str(sys.exc_value) + "\n"
    msgs = "ARCPY ERRORS:\n" + arcpy.GetMessages(2) + "\n"

    arcpy.AddError(msgs)
    arcpy.AddError(pymsg)

    print msgs
    print pymsg
    
    arcpy.AddMessage(arcpy.GetMessages(1))
    print arcpy.GetMessages(1)
